package CRS.classes;

import java.io.*;
import java.util.ArrayList;


public class sample_py {

    public static void sample_process() throws IOException, InterruptedException {
//        ProcessBuilder builder = new ProcessBuilder("/home/hasan/python/env/bin/python3",
//                "prac.py","-rd","/home/hasan/python");
        ProcessBuilder builder = new ProcessBuilder("/home/hasan/python/env/bin/python3",
                "/home/hasan/python/prac.py");
        builder.redirectErrorStream(true);
        Process process = builder.start();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        bufferedReader.lines().forEach(System.out::println);

    }

    public static void bash_process() throws IOException {
        ArrayList<String> ratings = new ArrayList<String>();

        try {
            FileWriter myWriter = new FileWriter("/home/hasan/python/weights.txt");
            for(int i = 0; i < 8; i++)
            {
                ratings.add("7");
                myWriter.write("7");
                if(i != 7)
                {
                    myWriter.write(",");
                }
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }


        ProcessBuilder processBuilder = new ProcessBuilder();
        ProcessBuilder processBuilder_1 = new ProcessBuilder();
        // -- Linux --
//        processBuilder.command("bash", "-c", "source /home/hasan/python/env/bin/activate");
        processBuilder.command("bash", "-c", "/home/hasan/python/env/bin/python3 /home/hasan/python/prac.py");
        try {
            Process process = processBuilder.start();
            StringBuilder output = new StringBuilder();
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line + "\n");
            }
            int exitVal = process.waitFor();
            if (exitVal == 0) {
                System.out.println("Success!");
                System.out.println(output);
//                processBuilder.command("bash", "-c", "python3 /home/hasan/python/prac.py");
//                System.out.println("Success!");
                System.exit(0);
            } else {
                //abnormal...
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

//    public static void main(String[] args) throws IOException, InterruptedException {
//        sample_py.sample_process();
//        sample_py.bash_process();
//    }

}
